# @velaros-ai/velaros/script

原生 Node.js 执行、语法检查与 Kernel 能力桥。模型默认使用标准命令、Node 标准库及工作区依赖；应用能力按需通过普通 ESM import 加载。工作目录、进程权限、审批与回收由宿主控制。

## 用法

```ts
import { createKernelScriptSession, createNodeCodeRunner, type NodeCodeRunnerOptions } from '@velaros-ai/velaros/script'
import type { OperationRuntimeApi } from '@velaros-ai/velaros/kernel'

declare const host: NodeCodeRunnerOptions
declare const kernel: OperationRuntimeApi
const session = createKernelScriptSession({
  runtime: kernel, runner: createNodeCodeRunner(host),
  sessionId: 'main', executionId: crypto.randomUUID(),
})
const result = await session.run({
  source: `import {readdir} from 'node:fs/promises'; console.log(await readdir('.'));`,
})
if (result.checked) console.log(result.result.process)
```

每个会话执行一次 Node.js ESM 程序，支持顶层 await。预装标准库见下表；无需先加载 Skill 或安装，用 `velaros:npm/<包名>` 显式选择宿主安装，例如 `import {execa} from "velaros:npm/execa"`。裸包名按 Node 的工作区规则解析，损坏的项目依赖保留原错误；宿主包子路径沿用该安装的 exports。stdout、stderr、退出状态和有界日志路径随结果返回。跨轮状态与复用脚本使用普通文件。


| 用途 | 默认 npm 包 |
| --- | --- |
| 命令、搜索、遍历、差异 | `execa`、`@vscode/ripgrep`、`globby`、`diff` |

基础 npm 只保留命令、搜索、路径查找和文本差异工具；文件与 JSON 处理使用 Node 标准库。默认包只在程序 import 时加载，发现目录只读取包元数据，不预加载库代码或把 README 塞进上下文。其余库由实际使用的工作区或能力模块自行声明，不作为基础依赖分发。`typescript`、`ts-morph` 和 `prettier` 由 JS/TS 能力按需提供，加载后从下一次程序执行起进入环境。Script 内部用于合同编译的 TypeScript 依赖不向基础任务环境公开。

`VELAROS_HOST_DIR/index.json` 提供当前授权包的名称、用途、操作名和合同路径。`operationDirectory` 下每个操作的 `.d.ts` 由正式声明生成，包含用途、签名、依赖类型、共同规则和调用示例；读取所需文件后按包名导入，例如 `import {list} from 'velaros:sessions'`。原生 Node 负责标准库、npm、文件导入与模块绑定；能力包由当前授权表生成，每次调用经 Kernel 校验。

目录的 `importer` 标明本次程序入口；`packages` 的版本、`packageJson`、README 与实际入口的工作区依赖对应，`source` 区分工作区解析和运行环境后备安装。`runtimeImport`、`runtimeVersion`、`runtimePackageJson` 和 `runtimeReadme` 同时给出显式宿主安装的身份与证据入口。包清单缺失或损坏时保留该条目的诊断，不借用其他版本的身份，也不影响无关程序。发现由本次 Node 进程读取，宿主在执行用户源码前一次发布；保存脚本中的其他入口仍按各自位置解析依赖。

同一目录的 `execution` 记录本次子进程实际的 `node` 版本、`executable`、`platform`、`arch`、`cwd` 和有序 `path`。它是启动时的环境事实，标准命令按该 PATH 和调用时的实际文件解析；宿主可通过 `environment.PATH` 指定命令搜索范围。目录只发布这些字段，其他环境变量与能力凭据保持私有。

宿主 `execute(request, onOutput, signal)` 执行 `request.entrypoint`；未提供入口文件的兼容宿主可将 `request.bootstrap ?? request.source` 作为 ESM 标准输入。`source` 始终保留审批原文。进程环境将所选 Node 的目录置于 PATH 首位，并在保留原 NODE_OPTIONS 的基础上追加 `--import request.preload`；Execa 启动的 Node 子进程、`execFile` 与 `fork` 因而继承本次能力包解析。入口与预加载只写入子进程环境，能力凭据的作用域和取消边界仍是本次执行。`mode: 'observe'` 需要实际只读进程口；不可用时拒绝启动。Platform 的 `createNodeExecutionEnvironment` 复用 execution 宿主的跨平台约束、输出与进程树回收，Desktop 提供随产品分发的真实 Node。

需要结构化归档时，按需导入 `velaros` 的 `output`；内部参数可从 `velaros:program` 的 `input`、`blobs` 读取。`output` 同步保存有界 JSON 快照，在异常、取消和超时后保留已经完成的输出。宿主观察进程只额外获得本次输出文件和本机会话桥的访问权限。每次执行使用独立目录与凭据。

## 入口

| 入口 | 运行环境 | 内容 |
| --- | --- | --- |
| `@velaros-ai/velaros/script` | Node | `createKernelScriptSession`、`createNodeCodeRunner`、`nodeSubprocessCodeRunner`、语法检查与 `scriptOutputs` |
| `@velaros-ai/velaros/script/contracts` | 任何进程 | 程序、诊断、结果、输出及相关上限 |

## 约定

- 一个会话对象只能 `run` 一次，再调拒绝 `CONFLICT`，下一次执行换新的 `executionId` 重建；`edit`、`check` 不执行代码，可以反复调。
- `scriptPackageCompiler.sliceExports` 按多个真实导出合并类型闭包，模块共同规则始终随切片保留；`index` 给真实值导出和声明、模板正文的 `contentRevision`。正文版本不代表授权或已读证明。
- 自定义包只能导入 Kernel 里挂载且在 `allowedModules` 范围内的模块；Node 标准库和工作区依赖由原生解析器提供，`velaros`（`output`）与 `velaros:program`（`input`、`blobs`）总在；`mode` 原样带进每次 Kernel 调用，程序改不了。
- 能力调用失败在程序里是能 `try/catch` 的异常；码里带 `DENIED`、`PERMISSION` 的拒绝另记进 `result.notices`，程序吞了异常模型也看得见。
- 能力调用期间停表，程序时钟不计入等待宿主回执的时间；超时回 `TIMEOUT`，`signal` 触发回 `ABORTED`，停下时没落定的调用会被叫停。引擎只记账不回滚。
- 源码、`blobs`、`input` 超过 `CodeSurfaceLimits` 直接拒（`check` 抛 `TOO_LARGE`，`run` 回 `failed.code` 为 `TOO_LARGE`），不截断照跑；返回值与日志超预算保留结尾，并在 `result.notices` 里说明。
- `output` 调用时拍 JSON 快照，原值在 `outcome.output`，没调 `output` 时完整返回值在 `outcome.rawValue`；按 key 调展示、重新投影用 `scriptOutputs`，规则见 [脚本输出观察](../../docs/architecture/script-output-observation.md)。
- 展示目录的 `totalChars` 与字段引用的 `chars` 按 JSON Pointer 召回正文的 UTF-16 长度计算：字符串为解码原文，其他值为紧凑 JSON。采集计量 `block.chars` 仍按原 JSON 编码大小计算；分页使用读取回执的 `offset + text.length`，到该页 `totalChars` 停止。
- 输出展示按实际交付编码把正文、目录、问题与省略说明计入整体预算；默认 JSON 保持结构化表示，text 对所有类型独立选择能完整放下的正文。未配置整体上限时，显式 `view.mode: 'full'` 且无数字块上限，按完整选中表示的有界编码申请份额，再由宿主分配；放不下仍交引用。`required` 的自动视图、数字块上限（含零）、整体配置、引用、摘要及选择视图保持原语义。text 在共享份额中先分配 required 和 high，再分配普通块；超出时在该预算内选择完整行或完整条目；短块用不完的份额按既定优先级返还给尚未完整展示的块。结构化结果保留短字段，长文本字段共享剩余预算，片段标明完整行范围与原值 JSON Pointer。块优先级、显式展示上限与原值归档保持各自语义。
- `nodeSubprocessCodeRunner` 是 POSIX Node 宿主的便利入口，使用当前目录和本机 Node；Electron、Windows 以及受限权限执行通过 `NodeCodeRunnerOptions` 注入实际进程端口。`NodeSubprocessRunnerIsReleaseReady` 保持 false，部署权限仍由宿主验收。

`NodeCodeRunnerOptions.acquireRuntime` 可在每次执行前获取 `NodeRuntimeLease`，其不可变环境优先于静态 `runtime`。租约的命令目录随 `NodeProcessRequest.binDirectories` 交给进程宿主；内置宿主会将其加入本次 PATH。进程树完整结束后释放，回收不完整时调用可选 retain 保留文件。

能力桥使用本地 Unix socket / Windows 命名管道。Windows + Bun 在支持 HTTP connection 处理器时通过 net 监听并交给同一 HTTP 鉴权处理器；执行结束关闭监听和接入连接。Bun 1.3.13 缺少该处理器，会明确拒绝而不挂起；Bun 1.4.3 已通过该兼容路径回归。此兼容路径不改变默认 POSIX 进程宿主的适用范围，测试条件与本机验证结果见[测试与平台支持](../../docs/engineering/testing.md)。


### 可选进程事实视图

外层脚本正常退出不代表内层命令成功，更不代表测试或业务通过。默认 console、exec 自由执行方式和既有视图不变；需要避免长日志淹没命令状态时，可显式交出普通 JSON 事实：

```js
import {execa} from 'velaros:npm/execa'
import {output} from 'velaros'
const r = await execa('node', ['check.mjs'], {reject: false, stdin: 'ignore', timeout: 30000})
output({
  exitCode: r.exitCode, failed: r.failed, signal: r.signal, code: r.code,
  timedOut: r.timedOut, isCanceled: r.isCanceled, isTerminated: r.isTerminated,
  isMaxBuffer: r.isMaxBuffer, durationMs: r.durationMs,
  shortMessage: r.shortMessage, message: r.message,
  stdout: r.stdout, stderr: r.stderr,
}, {key: 'check-process', priority: 'high', view: {mode: 'process'}})
```

- execa 的失败结果可能是 Error，`message` 等属性不可枚举。不要直接 `output(error)` 或依赖对象展开保存全部诊断；显式提取所需字段。输出仍遵循普通 JSON、无 getter、无环和采集上限合同。
- `scope: caller-provided-process` 表明这些是脚本提供的事实，不是宿主探测到的子进程状态。`processStatus` 只可能为 `failed`、`exited-zero`、`unknown`；失败标志、非零退出码或信号优先。只有明确 `exitCode: 0`、`failed: false` 且没有已知异常或畸形字段才显示 `exited-zero`。缺失或无效信息不补猜。
- `businessStatus` 始终为 `unknown`。视图不解析任意日志中的 “pass/fail”，不因退出码 0 推断测试执行数、业务完成或产物有效；需要专门报告或额外验收证据。
- 原值仍完整归档（在采集上限以内）；视图为 `excerpt`，不是完整结果。stdout/stderr 只给出原值 `rawRef`、JSON Pointer 和字符串 UTF-16 长度，可按来源分段续读；长诊断同样引用，不被截成假完整值。字段未提供时不虚构日志。这里的完整仅指调用者交出的原值，不保证子进程上游没有裁剪。
- `maxChars` 与全局预算照旧有效，放不下则仅给引用；该模式不与 `paths`、`lines`、`maxItems`、`edge` 组合。若要看具体日志片段，按引用续读或改用既有字段/文本视图。采集超限不会用截断日志冒充全量，超大日志应由调用者保存文件并交出真实来源。
