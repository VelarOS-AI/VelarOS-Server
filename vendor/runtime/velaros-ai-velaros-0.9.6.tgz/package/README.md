# @velaros-ai/velaros

模型在程序里 import 的 `velaros:*` 能力单元（连同它们底下的本机实现），加上把模型、脚本执行、Kernel 与上下文装成一条执行链的 Act 运行时。产品宿主用 `createRuntime` 开会话，按空间把各单元的能力挂进来；一个单元一个目录，各有自己的入口与 README。

## 用法

```ts
import { createNodeRuntime } from '@velaros-ai/velaros/node'

declare const apiKey: string

const runtime = await createNodeRuntime({
  cwd: '/absolute/execution',
  stateDirectory: '/absolute/state',
  binding: { executionIdentity: 'local-user', authorizationScope: 'approved-roots-v1' },
  localHost: { processConfinement: { mode: 'workspace-write', workspaceRoot: '/absolute/execution' } },
  model: {
    provider: 'openai',
    model: 'your-model',
    apiKey,
    baseURL: 'https://api.example.com/v1', // 换成实际模型服务地址
  },
})
try {
  const session = await runtime.openSession('main')
  for await (const event of session.submit('检查项目并完成修改和验证')) {
    if (event.type === 'accepted') console.log(event.text)
    else if (event.type === 'error') console.error(event.message)
  }
} finally {
  await runtime.close()
}
```

Node 装配器复用同一 Runtime，执行环境为 Node.js ESM；基础入口不自动建立 Host、项目或其他业务能力。文件、目录与 JSON 使用 Node 标准库；基础 npm 包与按需工具链见 [Script 默认库](../script/README.md)。模型通过 `exec({code})` 运行程序。项目工作区按需提供 `velaros:project` 的版本核对、原子提交和冲突撤回；应用能力通过运行目录中的 `index.json` 和操作声明发现。

## 入口

| 单元 | 入口 | 做什么 |
| --- | --- | --- |
| [act/runtime](act/runtime/README.md) | `@velaros-ai/velaros`、`@velaros-ai/velaros/contracts`、`@velaros-ai/velaros/renderer`、`@velaros-ai/velaros/node` | Act 运行时：`createRuntime`、会话与运行事件、把能力挂进来的工厂、给渲染进程的事件投影 |
| [act/system](act/system/README.md) | `@velaros-ai/velaros/act/system` | 模型自管理的 `velaros:system`：发现能力、会话目标、任务笔记与长期记忆、持久空间 |
| [act/search](act/search/README.md) | `@velaros-ai/velaros/act/search` | 有界高级搜索 `velaros:search` 与搜索支线里的证据读取 `velaros:evidence` |
| [act/agents](act/agents/README.md) | `@velaros-ai/velaros/act/agents` | 子任务 `velaros:agents` 与用户交互 `velaros:interaction` |
| [execution](execution/README.md) | `@velaros-ai/velaros/execution`、`/execution/local` | 宿主进程权限、环境、终止与终端管理 |
| [images](images/README.md) | `@velaros-ai/capabilities/images` | 看图 `velaros:images`：把图片交到模型眼前 |
| [sandbox](sandbox/README.md) | `@velaros-ai/capabilities/sandbox` | 演练沙箱 `velaros:sandbox`：在镜像里先跑，看过差量再落回 |
| [project](project/README.md) | `@velaros-ai/capabilities/project` | 受项目治理的文件 `velaros:project` 与问代码 `velaros:code`，连同项目内核与语言服务 |
| [computer](computer/README.md) | `@velaros-ai/capabilities/computer` | 桌面控制 `velaros:computer`：截主屏、鼠标、键盘 |
| [memory](memory/README.md) | `@velaros-ai/velaros/memory` | 长期记忆库：按作用域保存、列出与删除 Markdown 条目 |
| [office](office/README.md) | `@velaros-ai/capabilities/office` | 办公文档 `velaros:office`：Word、PowerPoint、Excel 与 PDF 的生成、读取、转换与预览 |
| [browser](browser/README.md) | `@velaros-ai/capabilities/browser` | 浏览器 `velaros:browser`、`velaros:devtools`、`velaros:cdp`，连同 CDP 驱动与 Electron 会话运行时 |
| [web](web/README.md) | `@velaros-ai/capabilities/web` | 网上查资料 `velaros:web`：搜索引擎搜、把网页读成文字，都在宿主给的不显示页面里跑 |
| [sessions](sessions/README.md) | `@velaros-ai/capabilities/sessions` | 会话之间交活、传话 `velaros:sessions`：同一个对话里的会话互相交活、等回答、捎话，会话的一切在宿主那里 |

各单元的子入口（`/contracts` 的可移植数据、`/local` 的本机实现、`/renderer`、`/electron`）见单元 README；模型能 import 的系统操作与可用条件见 [Act 能力目录](act/README.md)。

基础与显式扩展分别安装，安装身份、公开入口切换和恢复规则见 [ADR 0028](../../docs/decisions/0028-runtime-foundation-and-capability-distributions.md)。源码内单元仍按同仓入口维护，专项发行中的入口由发行器重定位到 `@velaros-ai/capabilities/*`。
